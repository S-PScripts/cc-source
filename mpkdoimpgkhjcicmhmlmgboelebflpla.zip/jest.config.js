// jest.config.js
module.exports = {
    verbose: true,
  };