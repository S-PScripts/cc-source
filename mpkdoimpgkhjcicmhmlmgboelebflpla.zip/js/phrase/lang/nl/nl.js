define([], function(){
return [ 
//Alcoholverslaving
["Alcoholverslaving",[1,2]],  
//Alcoholisme
["Alcoholisme",[1,2]],  
//Alcoholist
["Alcoholist",[1,2]],  
//Ontwenningsverschijnselen
["Ontwenningsverschijnselen",[1,2]],  
//Drugsverslaving
["Drugsverslaving",[1,2]],  
//Cocaïne
["Cocaïne",[1,2]],  
//Heroïne
["Heroïne",[1,2]],  
//Wiet
["Wiet",[1,1]],  
//Hasj
["Hasj",[1,1]],  
//Hallucinerende
["Hallucinerende",[1,2]],  
//Hallucineren
["Hallucineren",[1,2]],  
//Paddo's
["Paddo's",[1,1]],  
//Overdosis
["Overdosis",[1,2]],  
//Roken
["Roken",[1,1]],  
//Sigaretten
["Sigaretten",[1,1]],  
//Rookverslaving
["Rookverslaving",[1,1]],  
//Magische paddestoelen
["Magische paddestoelen",[1,1]],  
//Drugs gebruiken
["Drugs gebruiken",[1,2]],  
//amfetamine 
["Amfetamine ",[1,2]],  
//rookt blowtje
["rookt blowtje",[1,2]],  
//Biertjes
["Bier",[1,2]],  
//Biertjes
["Biertjes",[1,2]],  
//Antidepressiva
["Antidepressiva",[1,2]],  
//Afkickklinieken
["Afkickklinieken",[1,2]],  
//Onder invloed
["Onder invloed",[1,2]],  
//Verslaafde
["Verslaafde",[1,2]],  
//iemand die te veel alcohol drinkt
["Natkut",[1,2]],  
//Drugsdealer die verbonden is aan een bepaald etablissement
["Huisdealer",[1,2]],  
//Verslaving 
["Verslaving ",[1,2]],  
//Nerveus
["Nerveus",[4,1]],  
//Misbruik online
["Misbruik online",[4,2]],  
//Fysiek misbruik
["Fysiek misbruik",[4,2]],  
//Woede 
["Woede ",[4,1]],  
//Hulp
["Hulp",[4,1]],  
//Liegen 
["Leugen",[4,1]],  
//Leugenaar
["Leugenaar",[4,1]],  
//Liegen 
["Liegen ",[4,1]],  
//ploert schoft onbetamelijk iemand.
["Zwijnjak",[4,1]],  
//iemand die zich vies onbeschaafd of zeer slecht gedraagt.
["Zwijn",[4,1]],  
//Lik mijn testikels.
["Zuig mijn ballen",[4,1]],  
//iemand die steeds zeurt
["Zeurzak",[4,1]],  
//iemand die zeurt
["Zeurpiet",[4,1]],  
//iemand die steeds zeurt
["Zeurkous",[4,1]],  
//iemand die zeurt
["Zeur",[4,1]],  
//zenuwachtig persoon zenuwlijder
["Zenuwlijer",[4,2]],  
//iemand die zeer nerveus aangelegd is zenuwenlijder
["Zenuwenlijer",[4,2]],  
//zeurpiet
["Zeikstraal",[4,1]],  
//iemand die zeurt en klaagt
["Zeiksnor",[4,1]],  
//lafaard bangerik
["Zeiklijster",[4,1]],  
//zeurpiet
["Zeikhannes",[4,1]],  
//een zeurkous
["Zeikerd",[4,1]],  
//zeikerd zeurpiet zeikstraal zeikhannes
["Zeikbeer",[4,1]],  
//slijmerig persoon
["Zalfpot",[4,1]],  
//een sullig persoon die alles fout doet
["Zakkenwasser",[4,1]],  
//iemand die zich op oneigenlijke wijze verrijkt
["Zakkenvuller",[4,1]],  
//benaming voor iemand die weinig onthoudt niet goed nadenkt of niet slim is
["Zaagselkop",[4,1]],  
//meisje dat aanpapt met oudere mannen
["Wipkip",[4,1]],  
//walgelijk persoon of gezelschap
["Vullis",[4,1]],  
//iemand die gemene streken uithaalt
["Vuilak",[4,1]],  
//armoedig persoon met een gebrekkige hygiëne wellicht geplaagd door kleine bloedzuigende parasieten die op anderen kunnen overspringen
["Vlooienzak",[4,1]],  
//iemand die ontkent hoe ernstig de coronapandemie is of hierover bizarre ideeën en complottheorieën verspreidt
["Viruswappie",[4,1]],  
//Viespeuk
["Viezerik",[4,1]],  
//een dik persoon of dier
["Vetzak",[4,1]],  
//iemand met overgewicht
["Vetklep",[4,1]],  
//iemand die zich ongemanierd smerig of lui gedraagt
["Varken",[4,1]],  
//vrouw die verachtelijk wordt gevonden omdat ze met veel verschillende mannen seks heeft
["Variétéhoer",[4,2]],  
//Is een woord voor een naïef dom persoon
["Uilskuiken",[4,1]],  
//ellendeling
["Tyfuslijder",[4,1]],  
//Een milde belediging gericht op vrouwen
["Tut",[4,1]],  
//weinig aantrekkelijke en overdreven preutse vrouw
["Trut",[4,1]],  
//onaantrekkelijke of domme vrouw
["Troelala",[4,1]],  
//slordig wijf
["Totebel",[4,1]],  
//dik meisje dan wel vrouwspersoon in het algemeen
["Tietvlieg",[4,1]],  
//vervelend akelig persoon
["Teringlijer",[4,1]],  
//ellendeling
["teringlijder",[4,1]],  
//Teef betekent klote wijf
["Teef ",[4,1]],  
//onaangename of truttige vrouw die al wat ouder is
["Taart",[4,1]],  
//iemand die ergernis opwekt door het bekritiseren en corrigeren van kleine taalfouten van anderen
["Taalnazi",[4,1]],  
//Is een relatief milde belediging meestal gericht op jongens en mannen voor watje.
["Sukkel",[4,1]],  
//stom dik vervelend persoon
["Strontzak",[4,1]],  
//Een aantrekkelijk meid
["Stootje",[4,1]],  
//Achterlijke klootzak
["Stomme klootzak",[4,1]],  
//een dom of onachtzaam persoon
["Stomkop",[4,1]],  
//Stoephoer kan worden gebruikt als een belediging voor vrouwen
["Stoephoer",[4,2]],  
//gemeen persoon
["Stinkerd",[4,1]],  
//gemeen persoon
["Stinker",[4,1]],  
//iemand die stinkt
["Stinkbok",[4,1]],  
//koppig eigenwijs iemand die heel dom is
["Steenezel",[4,1]],  
//iemand die krampachtig doet en overdreven zenuwachtig is
["Spast",[4,1]],  
//dom persoon (meestal een vrouw)
["Soepkip",[4,1]],  
//smerig persoon
["Snotolf",[4,1]],  
//snotneus
["Snotaap",[4,1]],  
//opschepper
["Snoever",[4,1]],  
//schoft smeerlap
["Smiecht",[4,1]],  
//smeerpoets viezerik vuilak smeerlap
["Smeerpijp",[4,1]],  
//"Kan worden gebruikt om ""pervert"" te betekenen of meer in het algemeen om te verwijzen naar iemand van twijfelachtige moraliteit"
["Smeerlap",[4,1]],  
//smeerkees smeerlap vuilak smeerpoets
["Smeerkanis",[4,1]],  
//ordinaire vrouw
["Sloerie",[4,1]],  
//huichelachtig kruiperig overdreven onderdanig persoon
["Slijmerd",[4,1]],  
//Slet
["Slettenbak",[4,1]],  
//Slet
["Slet",[4,1]],  
//onaangenaam persoon mispunt ellendeling
["Sekreet",[4,1]],  
//onaangenaam persoon mispunt ellendeling kreng loeder
["Secreet",[4,1]],  
//een persoon die kwaad bedrijft
["Schurk",[4,1]],  
//door schurft aangetaste kop
["Schurftkop",[4,1]],  
//iemand (doorgaans van het mannelijk geslacht) die zich door zijn gedragingen gehaat maakt
["Schoft",[4,1]],  
//verdorven doortrapt slecht persoon
["Schobbejak",[4,1]],  
//vieze of verachtelijke vrouw vrouwelijke vorm van schimmelnek
["Schimmelkut",[4,2]],  
//iemand die geen moed heeft
["Schijtluis",[4,1]],  
//bangerd
["Schijtlijster",[4,1]],  
//Een lafaard
["Broekschijter",[4,1]],  
//Een lafaard
["Lafaard",[4,2]],  
//iemand die geen moed heeft
["Schijtlaars",[4,1]],  
//een vervelend persoon
["Schijthoofd",[4,1]],  
//bangerd
["Schijterd",[4,1]],  
//schurk
["Schelm",[4,1]],  
//dom of onnozel persoon
["Schaapskop",[4,1]],  
//verwensing wijzend op afschuw
["Sakkers",[4,1]],  
//Aftrekken
["Rukker",[4,2]],  
//Mastubeerder
["Rukhond",[4,2]],  
//iemand die zich schurkachtig gedraagt
["Rotzak",[4,1]],  
//iemand die alles doet om bij een baas in het gevlij te komen
["Retenlikker",[4,1]],  
//deugniet
["Rekel",[4,1]],  
//marginale imbeciel gek dwaas
["Randdebiel",[4,1]],  
//(Suriname) stommeling schoft
["Raas",[4,1]],  
//lomperd
["Pummel",[4,1]],  
//puistenkop
["Pukkelbek",[4,1]],  
//puber
["Puistenkop",[4,1]],  
//verachtelijk vrouwspersoon
["Pothoer",[4,1]],  
//Portiek hoer
["Portiekslet",[4,1]],  
//een persoon die populair probeert te zijn door naar het volk te spreken maar zonder echt inhoud te hebben
["Populist",[4,1]],  
//dikke vrouw
["Pommel",[4,1]],  
//vrouwelijke medewerker van de politie
["Politiemuts",[4,1]],  
//waardeloze vrouw
["Pokkenwijf",[4,1]],  
//ellendeling
["pokkenlijder",[4,1]],  
//lomp en onbeleefd persoon
["Plurk",[4,1]],  
//iemand die er door anderen van wordt beschuldigd te veel te hechten aan een bepaalde positie
["Plucheplakker",[4,1]],  
//schoft
["Ploert",[4,1]],  
//ellendeling
["Pleurislijder",[4,1]],  
//ellendeling kelerelijder tyfuslijder teringlijder pleurislijder
["Pestlijder",[4,1]],  
//gereformeerde
["Pepermuntvreter",[4,1]],  
//oude hoer
["Pekelhoer",[4,1]],  
//smeerlap fielt schurk
["Patjakker",[4,1]],  
//nietsnut snoever windbuil
["Pasjakroet",[4,1]],  
//grok onbehouwen persoon
["Palurk",[4,1]],  
//verachtelijk persoon iemand die niet deugt
["Pagadder",[4,1]],  
//kletskous kletsmajoor kletsmeier leuteraar
["Ouwehoedendoos",[4,1]],  
//stomme sufferd
["Ossenlul",[4,1]],  
//zich uit voeten maken weggaan
["Optyfen",[4,1]],  
//een klein persoontje
["Onderkruipsel",[4,1]],  
//dom sullig figuur
["Oen",[4,1]],  
//vrouw die voor haar plezier of voor kleine gunsten seks heeft met verschillende mannen
["Noppeshoer",[4,1]],  
//onwetende sukkel met weinig kennis van zaken
["Nitwit",[4,1]],  
//de penis van een man
["Neukpaal",[4,1]],  
//verachtelijke vent
["Netenvreter",[4,1]],  
//bedillerig vitziek ontevreden persoon
["Neetoor",[4,1]],  
//een onhandige of domme vrouw
["Muts",[4,1]],  
//onaantrekkelijke domme vrouw die geen kinderen kan krijgen
["Muilezelin",[4,1]],  
//vrouw die voor een geringe beloning tot seks bereid is
["Mosselhoer",[4,1]],  
//vrouw die zich onzedelijk gedraagt; onzedelijke vrouw
["Morsebel",[4,1]],  
//achterlijke persoon idioot
["Mongool",[4,1]],  
//vrouw die tijdens de Duitse bezetting in de Eerste of Tweede Wereldoorlog seks zou hebben gehad met iemand uit de bezettingsmacht
["Moffenhoer",[4,2]],  
//iemand van het platteland
["Modderduivel",[4,1]],  
//beroerd persoon ellendeling mispunt
["Mispunt",[4,1]],  
//beroerd persoon ellendeling mispunt
["Mispruim",[4,1]],  
//ordinair luidruchtig of wat agressief persoon
["Matje",[4,1]],  
//"Een matennaaier is letterlijk ""a buddy fucker"" iemand die een of meer van zijn vrienden heeft besodemieterd"
["Matennaaier",[4,1]],  
//lelijke vrouw heks
["Masque",[4,1]],  
//dwaas malloot
["Mafkikker",[4,1]],  
//dwaas malloot
["Mafketel",[4,1]],  
//iemand die niet meedoet (aan een staking o.i.d.)
["Maffer",[4,1]],  
//kluns; vervelend en/of lomp iemand (meestal een jongen of man)
["Lummel",[4,1]],  
//stomme vent sukkel
["Lulhannes",[4,1]],  
//"Lul is een woord voor de penis. Het wordt gebruikt als een belediging en is ongeveer analoog aan het Engelse ""dick"" wanneer het op een persoon wordt toegepast."
["Lul",[4,1]],  
//vernederende term voor iemand in het algemeen; ellendeling
["Luiskop",[4,1]],  
//vernederende term voor iemand in het algemeen; ellendeling
["Luibuis",[4,1]],  
//scheldwoord voor iemand die lui is een luiaard
["Luibak",[4,1]],  
//een sukkel stakker mislukkeling
["Lomperik",[4,1]],  
//een onhandig persoon
["Lomperd",[4,1]],  
//sluw verradelijk persoon
["Linkmiegel",[4,1]],  
//Lik mijn kont
["Lik mijn aars",[4,1]],  
//verachtelijk persoon
["Lijer",[4,1]],  
//iemand die er onaantrekkelijk uitziet of een slecht karakter heeft
["Lelijkerd",[4,1]],  
//waardeloos persoon lui persoon
["Lamstraal",[4,1]],  
//iemand die niet durft voor zichzelf op te komen
["Lafbek",[4,1]],  
//voor door iemand anders gemanipuleerd wordt.
["Labrat",[4,1]],  
//lafaard flauwerd flauwerik; iemand die tot niets komt waardeloos persoon
["Labbekak",[4,1]],  
//arrogant vervelend persoon
["Kwal",[4,1]],  
//iemand die bedrieglijk minderwaardige geneeskunde uitoefent
["Kwakzalver",[4,1]],  
//scheldwoord voor een vrouw
["Kutwijf",[4,1]],  
//een heel vervelende slechte man
["Kutvent",[4,1]],  
//irritante vrouw
["Kuttenkop",[4,1]],  
//gemene vervelende slechte handeling
["Kutstreek",[4,1]],  
//Vuile hoer
["Kuthoer",[4,1]],  
//Kus me ballen
["Kus mijn kloten",[4,1]],  
//kruiperig persoon een slijmerd
["Kruiper",[4,1]],  
//vrouw die regelmatig een miskraam heeft
["Kruimelbuik",[4,1]],  
//slechte zanger
["Krijslijster",[4,1]],  
//een klein persoon
["Krielkip",[4,1]],  
//kleintje klein persoon
["Kriel",[4,1]],  
//gemeen of onaangenaam persoon (meestal van het vrouwelijke geslacht)
["Kreng",[4,1]],  
//iemand die tegenover een iemand die meer geld of macht heeft overdreven vriendelijk en meegaand is
["Kontkruiper",[4,1]],  
//iemand die zich dom of onhandig gedraagt
["Kokosmakroon",[4,1]],  
//bangerik angsthaas schijtlaars
["Knijpkont",[4,1]],  
//een onhandig persoon
["Kluns",[4,1]],  
//beroerd slecht waar men grote afkeer van heeft
["Klote",[4,1]],  
//een vervelende man (die iemand of een groep mensen een gemene streek heeft geleverd)
["Klootzak",[4,1]],  
//enorme sukkel kloothommel
["Klootviool",[4,1]],  
//Klojo
["Klootoog",[4,1]],  
//klootzak
["Kloothommel",[4,1]],  
//ergerlijke sukkel van een man
["Kloothannes",[4,1]],  
//stuntel
["Klooi",[4,1]],  
//iemand die aanrommelt domme dingen doet
["Klojo",[4,1]],  
//lomperik
["Kloefkapper",[4,1]],  
//Kleine stoute klootzak
["Klerebeer",[4,1]],  
//beroerd slecht waar men grote afkeer van heeft
["Klere",[4,1]],  
//scheldnaam voor een man
["Klaplul",[4,1]],  
//politieagent (in de decennia na de Tweede Wereldoorlog)
["Klapluis",[4,1]],  
//scheldwoord voor een vrouw
["Klapkut",[4,1]],  
//scheldnaam voor een vrouw
["Klafte",[4,1]],  
//afschuwelijk of pietluttig persoon
["Kippenneuker",[4,1]],  
//pummel lomperd
["Kinkel",[4,1]],  
//minderwaardige vrouw
["Keutelkut",[4,1]],  
//rotzak
["Kelerelijer",[4,1]],  
//hond
["Keilef",[4,1]],  
//(scheldwoord) voor een Hollander of patriot
["Kees",[4,1]],  
//vrouw die zich gemeen of walgelijk gedraagt (soms ook gebruikt voor mannen)
["Karonje",[4,1]],  
//lomperd botterik
["Karhengst",[4,1]],  
//opschepper
["Kapsoneslijer",[4,1]],  
//fantasieloze saaie man die op een bureau werkt
["Kantoorpik",[4,1]],  
//rotzak
["Kankerlijer",[4,1]],  
//een ellendeling kelerelijder tyfuslijder teringlijder pleurislijder
["Kankerlijder",[4,1]],  
//diep beledigend scheldwoord
["Kankerhond",[4,1]],  
//verachtelijke vrouw
["Kankerhoer",[4,1]],  
//benaming voor iemand die erg dik is
["Kamerolifant",[4,1]],  
//iemand die erg tevreden is over zichzelf en daarom onverdiend de aandacht opeist
["Kakmaker",[4,1]],  
//bekakt en verwaand vrouwspersoon
["Kakmadam",[4,1]],  
//verachtelijk persoon
["Kakkerlak",[4,1]],  
//slet hoer
["Kakhuis",[4,1]],  
//"Kak betekent ""rotzooi"". Hoewel het niet langer algemeen wordt gebruikt in godslastering wordt het nog steeds gebruikt als een sociale slu"
["Kak",[4,1]],  
//lomperd stommeling
["Kaffer",[4,1]],  
//ontuchtige blanke of Nederlandse vrouw
["Kaashoer",[4,1]],  
//blanke Nederlander
["Kaas",[4,1]],  
//Je kunt mijn kont kussen
["Je kunt me de kont kussen",[4,1]],  
//Idioot
["Idioot",[4,1]],  
//flapdrol
["Huzarenhoop",[4,1]],  
//onnozele vrouw
["Huppelkut",[4,1]],  
//man die zich lomp onbehouwen en/of aanstootgevend gedraagt
["Hufter",[4,1]],  
//verachtelijk waardeloos persoon geitenneuker kippenneuker
["Hondenneuker",[4,1]],  
//scheldwoord in het bijzonder voor voetbalscheidsrechters
["Hondenlul",[4,1]],  
//minderwaardig persoon
["Hond",[4,1]],  
//onwettige onechte zoon bastaard
["Hoerenzoon",[4,1]],  
//Iemand die naar de hoeren gaat
["Hoerenloper",[4,1]],  
//bastaard 'onecht' kind
["Hoerenkind",[4,1]],  
//Zoon van een hoer
["Hoerenjong",[4,1]],  
//man die vaak de diensten van prostituees gebruikt
["Hoerenjager",[4,1]],  
//Hoer
["Hoer",[4,1]],  
//kakkerig meisje uit de gegoede ('Gooise') kringen
["Hockeytut",[4,1]],  
//kakkerig meisje uit de gegoede kringen dat deze elitesport beoefent
["Hockeytrut",[4,1]],  
//imbeciel
["Hersenlijer",[4,1]],  
//onaangename lastige vrouw
["Heks",[4,1]],  
//lomperd
["Heikneuter",[4,1]],  
//pummel
["Heihaas",[4,1]],  
//feeks
["Harpij",[4,1]],  
//heel vreemde snurker
["Hapsnurker",[4,1]],  
//nietsnut
["Halvezool",[4,1]],  
//hebzuchtig inhalig persoon (met een grote bek)
["Haai",[4,1]],  
//iemand die op grove manier onbeleefd is pummel
["Grobbejanus",[4,1]],  
//Een slet
["Greppeldel",[4,1]],  
//rotwijf mager persoon
["Gratenbaal",[4,1]],  
//Goedkope hoer
["Goedkope hoer",[4,1]],  
//gluiperd
["Gluipsnor",[4,1]],  
//Iemand die gluipt. Slinkse streken uithaalt vals is en/of huichelachtig kijkt
["Gluiperd",[4,1]],  
//Iemand die gluipt. Slinkse streken uithaalt vals is en/of huichelachtig kijkt
["Gluiper",[4,1]],  
//geboefte gespuis uitvaagsel
["Geteisem",[4,1]],  
//sukkel
["Geitenbreier",[4,1]],  
//scheldwoord voor een vrouw
["Geit",[4,1]],  
//dief oplichter schurk
["Gannef",[4,1]],  
//een waardeloos of verdorven persoon
["Galgenbrok",[4,1]],  
//onaangenaam persoon
["Foefkop",[4,1]],  
//iemand die mensen geld afhandig maakt door ze te bedriegen
["Flessentrekker",[4,1]],  
//vrouw die er zeer onverzorgd uitziet of snel bereid is tot seksueel verkeer
["Fleer",[4,1]],  
//vent van niets slappeling
["Flapdrol",[4,1]],  
//schoft
["Fielt",[4,1]],  
//domkop
["Ezel",[4,1]],  
//zeer onaangenaam persoon
["Etterbuil",[4,1]],  
//een onaangenaam persoon
["Etter",[4,1]],  
//persoon die bij anderen angst en afkeer oproept
["Engerling",[4,1]],  
//Dom persoon. Sufferd zak.
["Eikel",[4,1]],  
//stommeling sufferd
["Eendenkont",[4,1]],  
//persoon zonder enig begripsvermogen
["Ectoplasma",[4,1]],  
//iemand die onverstandig denkt en/of handelt
["Dwaas",[4,1]],  
//sufferd sukkel uilskuiken idioot
["Druiloor",[4,1]],  
//sullig dom persoon
["Droplul",[4,1]],  
//iemand die niet kan toveren en ook niet weet dat magie bestaat in de boeken en films van Harry Potter
["Dreuzel",[4,1]],  
//een vrouw een vagina
["Doos",[4,1]],  
//Stomme slet
["Domme Kutslet",[4,1]],  
//opgedirkte vrouw
["Dirkdoos",[4,1]],  
//vrouw die zich ethisch wil gedragen
["Deuggleuf",[4,1]],  
//iemand met een gebrekkige geestelijke ontwikkeling
["Cretin",[4,1]],  
//iemand die tijdens de coronapandemie de maatregelen tegen de verspreiding van het coronavirus niet naleeft
["Covidioot",[4,1]],  
//rotzak
["Coronalijer",[4,1]],  
//boekhouder
["Cijferneuker",[4,1]],  
//een vrouw die voor een onbeduidende vergoeding seks heeft met mannen
["Chocoladesnol",[4,1]],  
//een vrouw die voor een onbeduidende vergoeding seks heeft met mannen
["Chocoladehoer",[4,1]],  
//Soms charmante oplichter (deskundige) gespecialiseerd in bedrog over zijn afkomst vaardigheden intenties of prestaties.
["Charlatan",[4,1]],  
//iemand die zich voortdurend afkeurenswaardig gedraag
["Bulderbast",[4,1]],  
//iemand die zich voortdurend afkeurenswaardig gedraagt
["Broodaap",[4,1]],  
//brildrager
["Brilsmurf",[4,1]],  
//losbandig meisje dat ter zelfbevestiging de slet uithangt
["Breezerslet",[4,1]],  
//dik persoon
["Braadvarken",[4,1]],  
//lomperd
["Botterik",[4,1]],  
//vreemde snuiter primitief persoon
["Bosneuker",[4,1]],  
//gemene vent
["Bokkenrijder",[4,1]],  
//Penis van een ram
["Bokkelul",[4,1]],  
//lompe ongemanierde vrouw
["Boerin",[4,1]],  
//lomperd nog lomper dan een gewone pummel
["Boerenpummel",[4,1]],  
//een lomperd
["Boerenkinkel",[4,1]],  
//lomperd botterik
["Boerenkarhengst",[4,1]],  
//lomperd
["Boerenkaffer",[4,1]],  
//lomperd botterik
["Boerenhufter",[4,1]],  
//een onbeschaafd onwetend persoon
["Boerenheikneuter",[4,1]],  
//treiteraar
["Bloedlijer",[4,1]],  
//man met een kaal hoofd
["Biljartbal",[4,1]],  
//zoveelste variant om (vermeend) sletterig gedrag te benoemen
["Bermslet",[4,1]],  
//deugniet
["Bengel",[4,1]],  
//ondeugende jongen
["Belhamel",[4,1]],  
//"Bek (""bek van dieren"") wordt het meest gebruikt in de uitdrukking ""houd je bek"" (""houd je mond"")"
["Bek",[4,1]],  
//(Jiddisch-Hebreeuws) (scheldwoord) rund (vooral voor domme vrouw)
["Beheime",[4,1]],  
//scheldwoord voor iemand die slaafs anderen naloopt
["Bedrijfspoedel",[4,1]],  
//slet die in een bar opereert
["Barslet",[4,1]],  
//iemand die bang is
["Bangerd",[4,1]],  
//viezerik smeerkees
["Baggerduiker",[4,1]],  
//rare kerel iemand die zich vreemd gedraagt
["Badgast",[4,1]],  
//iemand die zich dom of bot gedraagt
["Babok",[4,1]],  
//Als prostituee klanten lokken vanachter een verlicht raam
["Achter het raam zitten",[4,1]],  
//Neuken betekent letterlijk neuken
["Neuken",[4,1]],  
//Vagina
["Kut",[4,1]],  
//De zus uitmaken voor hoer
["Je zuster is een hoer.",[4,1]],  
//Is sociale smet verwijzend naar mensen met een hogere sociale status dan de spreker vergelijkbaar met mensen uit bijvoorbeeld Wassenaar
["Kakker",[4,1]],  
//Achterlijke
["Debiel",[4,1]],  
//Pesten
["Pesten",[4,2]],  
//Huiselijk geweld
["Huiselijk geweld",[4,3]],  
//Misbruik kindertijd
["Misbruik kindertijd",[8,3]],  
//Niet tegen je ouders zeggen
["Vertel niet je ouders",[8,2]],  
//Praat smerig tegen me
["Praat smerig tegen me",[8,2]],  
//Hoe oud ben je eigenlijk
["Hoe oud ben je?",[8,2]],  
//Kindermishandeling
["Kindermishandeling",[8,3]],  
//Mensenhandel
["Mensenhandel",[8,3]],  
//iemand die anale seks bedrijft
["Sodomiet",[32,2]],  
//homoseksueel
["Sodemieter",[32,2]],  
//man met een seksuele voorkeur voor andere mannen
["Sodeflikker",[32,2]],  
//homoseksueel
["Homoseksueel",[32,2]],  
//homoseksueel
["Homoseksueler",[32,2]],  
//homoseksueel
["Homoseksueelst",[32,2]],  
//homoseksueel
["Homoseksuele",[32,2]],  
//homoseksueel
["Homofiel",[32,2]],  
//Lesbisch
["Lesbisch",[32,2]],  
//scheldnaam voor een jood
["Smous",[32,2]],  
//homoseksuele vrouw lesbienne
["Schuurmeid",[32,1]],  
//stoere homo
["Ruigpoot",[32,2]],  
//homoseksueel
["Rugridder",[32,2]],  
//homoseksueel
["Reetveger",[32,2]],  
//homoseksueel
["Reetroeier",[32,2]],  
//homoseksueel
["Reetridder",[32,2]],  
//homoseksueel
["Reetkever",[32,2]],  
//Homo
["Poot",[32,2]],  
//(slappe verwijfde) homo
["Mietje",[32,2]],  
//man met seksuele voorkeur voor mannen
["Kontneuker",[32,2]],  
//scheldwoord voor een homofiel
["Kankernicht",[32,2]],  
//homo homoseksueel geaard persoon
["Heaumeau",[32,2]],  
//voor transseksueel iemand de een geslachtsoperatie ook lichamelijk vrouw is geworden
["Bouwdoos",[32,2]],  
//homoseksuele man (Surinaams woord)
["Boeler",[32,2]],  
//"Kan worden gebruikt om ""homo"" aan te duiden"
["Nicht",[32,1]],  
//Verwijst naar een vrouw die op een man lijkt
["Manwijf",[32,1]],  
//Anale seks hebben
["Kontneuken",[32,1]],  
//Flikker is gelijk homo
["Flikker",[32,2]],  
//Mannen die seks met mannen hebben
["Bruinwerker",[32,2]],  
//Het wordt gebruikt om mannen te beledigen die seks hebben met mannen
["Anusridder",[32,2]],  
//Facist
["Fascistisch",[64,2]],  
//Terroristische bomaanslagen
["Terroristische bomaanslagen",[64,2]],  
//Terroristische aanslagen
["Terroristische aanslagen",[64,2]],  
//Naar Syrie reizen
["Reizen naar Syrië",[64,1]],  
//NSBer verwijst naar de Nationaal-Socialistische Beweging in Nederland. Het wordt over het algemeen gebruikt voor iemand die iemands acties verraadt aan autoriteiten
["NSBer",[64,1]],  
//Daad van vergelding
["Daad van vergelding",[64,1]],  
//Suïcide
["Suïcide",[128,4]],  
//Praten over zelfmoord
["Wil dat alles tot het einde",[128,4]],  
//Maak er een einde aan
["Beëindig het allemaal",[128,4]],  
//Praten over zelfmoord
["Zelfmoord",[128,4]],  
//Eetverslavingen
["Eetverslavingen",[256,2]],  
//Boulimia. Eetstoornis.
["Boulimia",[256,2]],  
//Ongebruikelijke eetgewoonten
["Ongebruikelijke eetgewoonten",[256,2]],  
//Gewichtsverlies
["Gewichtsverlies",[256,2]],  
//Eetstoornis
["Eetstoornis",[256,2]],  
//Seksverslaving
["Seksverslaving",[512,0]],  
//Een poëtische manier om vagina te zeggen.
["Liefdesgrot",[512,1]],  
//Zichzelf verwonden
["Zichzelf verwonden",[1024,3]],  
//Snijwonden
["Snijwonden",[1024,3]],  
//Kneuzingen
["Kneuzingen",[1024,3]],  
//Brandwonden 
["Brandwonden ",[1024,3]],  
//Kale plekken
["Kale plekken",[1024,2]],  
//Trekken van haar
["Trekken van haar",[1024,3]],  
//Tekens verbergen
["Tekens verbergen",[1024,3]],  
//Zelf pijniging
["Snijden",[1024,3]],  
//Zelf pijniging
["Zelfverwonding",[1024,3]],  
//Zelf pijniging
["Automutilatie",[1024,3]],  
//Zelfverminking
["Zelf verminking",[1024,3]],  
//Zelfverwonding
["Zelf pijniging",[1024,3]],  
//Verbergen van littekens
["Verbergen van littekens",[1024,3]],  
//In het gezicht steken
["Steek mijn gezicht",[1024,3]],  
//Krassen maken aan de kont
["Krassen op mijn kont",[1024,3]],  
//Krassen maken op de arm
["Krassen op mijn arm",[1024,3]],  
//Jezelf haten
["Ik haat mezelf",[1024,3]],  
//Zelfverminking
["Zelfbeschadiging",[1024,2]],  
//iemand met en donkere huidskleur.
["Zwartjoekel",[2048,2]],  
//iemand met en donkere huidskleur.
["Zwartjan",[2048,2]],  
//persoon van Oost-Aziatische herkomst bijvoorbeeld een Chinees Japanner of Vietnamees
["Spleetoog",[2048,2]],  
//Spanjaard
["Specht",[2048,2]],  
//Italiaan
["Spaghettivreter",[2048,2]],  
//scheldwoord voor een niet-blanke een kleurling en meer in het bijzonder een moslim
["Schapenneuker",[2048,2]],  
//(racistisch) iemand van Indische afkomst
["Sambalvreter",[2048,2]],  
//nog erger dan mof (scheldnaam voor een Duitser)
["Rotmof",[2048,2]],  
//iemand met een donker gekleurde huid
["Roetmop",[2048,2]],  
//Chinees of iemand met Aziatisch uiterlijk
["Pindapoepchinees",[2048,2]],  
//iemand met een Oost-Aziatisch uiterlijk
["Pindachinees",[2048,2]],  
//Chinees of iemand met Aziatisch uiterlijk
["Pinda",[2048,2]],  
//kleurlingenhater
["Pigmentvreter",[2048,2]],  
//scheldnaam voor mensen uit Hasselt
["Ossenkop",[2048,2]],  
//scheldwoord voor Italiaan
["Olijfneuker",[2048,2]],  
//Duitsland
["Moffrika",[2048,2]],  
//iemand vanuit Noord-Afrika
["Makaak",[2048,2]],  
//Italiaan
["Macaronivreter",[2048,2]],  
//Zuid-Afrikaans Nederlands: kleurling; persoon van gemengd ras
["Kroeskop",[2048,2]],  
//kleurling
["Koffieboon",[2048,2]],  
//(racistisch): Marokkaan
["Koeskoesvreter",[2048,2]],  
//scheldwoord voor Arabier
["Kamelenneuker",[2048,2]],  
//persoon zonder of met weinig beschaving
["Boer",[2048,2]],  
//blanke
["Bleekscheet",[2048,2]],  
//is een etnische smet voor mensen van Midden Oosterse afkomst
["Zandneger",[2048,2]],  
//Poepchinees is een etnische smet die wordt gebruikt tegen mensen van Aziatische afkomst
["Poepchinees",[2048,2]],  
//Neger is een term die wordt gebruikt om zwarte mensen te beschrijven analoog aan het Engelse woord neger
["Neger",[2048,2]],  
//Is een etnische smet die wordt gebruikt voor mensen van Duitse afkomst vergelijkbaar met kraut
["Mof",[2048,2]],  
//Letterlijk kaaskop een woord voor blanke Nederlanders
["Kaaskop",[2048,1]],  
//Geitenneuker is een etnische smet die van toepassing is op moslims of mensen van Midden-Oosterse afkomst
["Geitenneuker",[2048,1]],  
//is een etnische smet voor mensen met een donkere huid
["Aap",[2048,1]],  
//Racisme
["Racisme",[2048,2]],  
//Gokverslaving
["Gokverslaving",[16384,2]],  
//Schuld
["Schuld",[16384,2]],  
//Schuld
["Schulden",[16384,2]],  
//Gokken
["Gokken",[16384,2]],  
//Hacken
["Hacken",[32768,1]],  
//Cyberbeveiliging
["Cyberbeveiliging",[32768,1]],  
//Welzijn
["Welzijn",[65536,3]],  
//Somber
["Somber",[65536,3]],  
//verdrietig
["Verdrietig",[65536,2]],  
//Overstuur
["Overstuur",[65536,2]],  
//Psychische problemen
["Psychische problemen",[65536,3]],  
//Slecht slapen
["Slecht slapen",[65536,2]],  
//Angstig
["Angstig",[65536,3]],  
//Gespannen voelen
["gespannen voelen",[65536,2]],  
//Fysieke problemen
["Fysieke problemen",[65536,2]],  
//Trillen en zweten
["Trillen en zweten",[65536,3]],  
//Geestelijke verwarring
["Geestelijke verwarring",[65536,2]],  
//Psychose
["Psychose",[65536,3]],  
//Slechte concentratie
["Slechte concentratie",[65536,2]],  
//Depressie
["Depressie",[65536,3]],  
//Angststoornis
["Angststoornis",[65536,2]],  
//Angst
["Angst",[65536,3]],  
//Paniekerig
["Paniekerig",[65536,3]],  
//Depressief
["Depressief",[65536,3]],  
//Uitgeput
["Uitgeput",[65536,2]],  
//Zelfhulp 
["Zelfhulp ",[65536,2]],  
//Gameverslaving
["Gameverslaving",[65536,2]],  
//Depressieve gevoelens
["Depressieve gevoelens",[65536,2]],  
//Slechte dagen
["Slechte dagen",[65536,2]],  
//Sombere 
["Sombere ",[65536,2]],  
//Neerslachtig
["Neerslachtig",[65536,2]],  
//Futloos.
["Futloos",[65536,2]],  
//Ongemotiveerd.
["Ongemotiveerd",[65536,2]],  
//Slaapproblemen
["Slaapproblemen",[65536,2]],  
//Oververmoeidheid
["Oververmoeidheid",[65536,2]],  
//Verminderde energie
["Verminderde energie",[65536,2]],  
//Waardeloos 
["Waardeloos ",[65536,2]],  
//Emotionele pijn
["Emotionele pijn",[65536,3]],  
//Rouw
["Rouw",[65536,2]],  
//Seksualiteit
["Seksualiteit",[65536,2]],  
//Laag zelfbeeld
["Laag zelfbeeld",[65536,2]],  
//Gevoelens van isolatie
["Gevoelens van isolatie",[65536,2]],  
//Tranen 
["Tranen ",[65536,2]],  
//Lage motivatie
["Lage motivatie",[65536,2]],  
//Droefheid
["Droefheid",[65536,2]],  
]; 
});
